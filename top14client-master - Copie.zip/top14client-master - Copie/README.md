# top14client
Client Android pour l'application TOP14

## Description
Application Android qui se connecte à un service Web RESTful et qui récupère la liste des club de rugby du TOP 14.


## Changelog
2018-03-11 : commit initial
